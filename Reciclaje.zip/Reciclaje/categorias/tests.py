from django.test import TestCase
from .models import Jugador

# Create your tests here.
class RegistroTestCase(TestCase):
    def setUp(self):
        Jugador.objects.create(nombreJugador="Benjamin Riquelme",generoJugador="h",edadJugador="20",puntajeTotal="0",correoJugador="Benjamin@mishi.com",usuarioJugador="Riot",contraseñaJugador="Alboroto1234")
        Jugador.objects.create(nombreJugador="Nicole Donoso",generoJugador="f",edadJugador="21",puntajeTotal="0",correoJugador="Nicole@doggo.com",usuarioJugador="Destroyer",contraseñaJugador="Fuckmundo1234")

    def test_registrarse_(self):
        
        b = Jugador.objects.get(nombreJugador="Benjamin Riquelme")
        n = Jugador.objects.get(nombreJugador="Nicole Donoso")