from django import forms

from django.contrib.auth.models import User
from .models import Jugador
from .models import Usuario

class RegModelForm(forms.ModelForm):
    model = User
    fields = ['nombre','genero','email','usuario','contraseña']

GENDER_CHOICES = (
   ('M', 'Male'),
   ('F', 'Female')
)
    
class RegistrarseForm(forms.Form):
     nombreJugador = forms.CharField(max_length=20,label='Nombre',widget=forms.TextInput())
     generoJugador = forms.ChoiceField(choices=GENDER_CHOICES, widget=forms.RadioSelect())
     edadJugador = forms.IntegerField(label='Edad',widget=forms.NumberInput())
     correoJugador = forms.EmailField(label='Correo',widget=forms.EmailInput())
     usuarioJugador= forms.CharField(label='Usuario',widget=forms.TextInput())
     contraseñaJugador = forms.CharField(label='Contraseña', widget=forms.PasswordInput())
     

def get_context(self, name, value, attrs):
        context = super().get_context(name, value, attrs)
        if self.allow_multiple_selected:
            context['widget']['attrs']['multiple'] = True
        return context
@staticmethod
def _choice_has_empty_value(choice):
        """Return True if the choice's value is empty string or None."""
        value, _ = choice
        return value is None or value == ''

def use_required_attribute(self, initial):
        """
        Don't render 'required' if the first <option> has a value, as that's
        invalid HTML.
        """
        use_required_attribute = super().use_required_attribute(initial)
        # 'required' is always okay for <select multiple>.
        if self.allow_multiple_selected:
            return use_required_attribute

        first_choice = next(iter(self.choices), None)
        return use_required_attribute and first_choice is not None and self._choice_has_empty_value(first_choice)


class JuegoForm(forms.Form):
   preguntas = forms.CharField(max_length=70)
   respuesta = forms.CharField(max_length=70)
   correcta= forms.IntegerField()
      #
#
       # Labels = {
       #    'nombre' :'Nombre',
       #     'genero':'Genero',
       #     'edad':'Edad',
       #     'email':'Correo',
      #      'usuario':'Usuario',
       #     'contraseña':'Contraseña',

       # }
     #