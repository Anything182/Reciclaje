from django.shortcuts import render,redirect
#from numpy import *

# Create your views here.

from django import forms

from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from django.contrib.auth import logout as do_logout
from django.contrib.auth import login as do_login
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate
from .models import Pregunta,Respuesta,Perfil,Juego,Jugador

from .form import RegistrarseForm,JuegoForm

from random import randint

def index(request):
    """
    Función vista para la página inicio del sitio.
    """
    # Genera contadores de algunos de los objetos principales
    # Renderiza la plantilla HTML index.html con los datos en la variable contexto
    return render(request,'index.html')

# ---------------------------------------------------------------
def CRUD(request):
    return render(request,'eliminarJugador.html')
# ---------------------------------------------------------------
def Aceite(request):
    return render(request,'Aceite.html')

# ---------------------------------------------------------------
def Mapa(request):
    return render(request,'Mapa.html')

# ---------------------------------------------------------------
def Bronce(request):
  
    return render(request,'Bronce.html')
# ---------------------------------------------------------------
def Carton(request):

    return render(request,'Carton.html')
# ---------------------------------------------------------------
def Electrodomesticos(request):

    return render(request,'Electrodomesticos.html')
# ---------------------------------------------------------------
def Metales(request):

    return render(request,'Metales.html')
# ---------------------------------------------------------------
def Neumaticos(request):

    return render(request,'Neumaticos.html')
# ---------------------------------------------------------------
def Plasticos(request):

    return render(request,'Plasticos.html')
# ---------------------------------------------------------------
def Tapas(request):

    return render(request,'Tapas.html')
# ---------------------------------------------------------------
def Telgopor(request):

    return render(request,'Telgopor.html')
# ---------------------------------------------------------------
def TetraPack(request):

    return render(request,'TetraPack.html')
# ---------------------------------------------------------------
def Textiles(request):

    return render(request,'Textiles.html')
# ---------------------------------------------------------------
def Vidrios(request):

    return render(request,'Vidrios.html')

# ---------------------------------------------------------------
def Inicio(request):

    return render(request,'Inicio.html')

# ---------------------------------------------------------------
def login(request):
    return render(request,'login.html')
# ---------------------------------------------------------------
def Registro(request):
    return render(request,'Registro.html')
# ---------------------------------------------------------------
def PagJuego(request):
    return render(request,'pag.html')

# ---------------------------------------------------------------
def Juego(request):
    return render(request,'Juego.html')

# ---------------------------------------------------------------
def listarRegistro(request):
    ju = Jugador.objects.all()
    context = {'Jugador':ju}
    return render(request,'listarJugadores.html',context)


# ---------------------------------------------------------------
def modificarJugador(request):
    ju = Jugador.objects.get(id=id)
    if request.method == 'GET':
        form = JugadorForm(instance = ju)
    else:
        form = JugadorForm(request.POST,instace = ju)
        if form_is_valid():
            form.save()
        return redirect('index')
    
    return render(request,'crearJugado.html',{'form':form})
# ---------------------------------------------------------------
def eliminarJugador(request,id):
    ju = Jugador.objects.get(id=id)
    if request.method=='POST':
        ju.delete()
        return redirect('index')
    return render(request,'eliminarJugador.html',{'jugador':ju})
# ---------------------------------------------------------------
def Prueba(request):
    form = RegistrarseForm(request.POST or None)
    if form.is_valid():
        form_data = form.cleaned_data
        a = (form_data.get("nombreJugador"))
        b = (form_data.get("generoJugador"))
        c = (form_data.get("edadJugador"))
        d = (form_data.get("correoJugador"))
        e = (form_data.get("usuarioJugador"))
        f = (form_data.get("contraseñaJugador"))
        g =0
        obj = Jugador.objects.create(nombreJugador = a, generoJugador= b, edadJugador = c, correoJugador= d, usuarioJugador = e, contraseñaJugador = f, puntajeTotal = g)
        obj.save()


        x= User.objects.create(username=e,password=f)
        x.save()

    context ={
          "el_form":form,
    }
    return render(request,'RegistroForm.html',context)
# ---------------------------------------------------------------
#def Juego(request):
#   a=array([[p],[gr]])  #

 #   ale =randint(2,25) #genero numero aleatorio para el id de la pregunta que deseo mostrar
 #   p = Pregunta.objects.get(id=ale) #guardo en variable p todos los registros de mi tabla que contengan el id generado
#    gr =Respuesta.objects.filter(pregunta=2) #busco todos los registros en respuestas que esten asociados al id de la pregunta generada
 #   return render(request,'Juego.html',{'p2':p,'gr1':gr}) #envio como tercer parámetro las variables donde guarde los registros de mis tablas para que los reciba el html

# ----------------------------------------------------------------------------
#def FormGame(request):
 #   ale =randint(1,24) #genero numero aleatorio para el id de la pregunta que deseo mostrar
  #  p = Pregunta.objects.get(id=ale) #guardo en variable p todos los registros de mi tabla que contengan el id generado
   # gr =Respuesta.objects.filter(pregunta=2) #busco todos los registros en respuestas que esten asociados al id de la pregunta generada
    #return render(request,'FormularioGame.html',{'p2':p,'gr1':gr}) #envio como tercer parámetro las variables donde guarde los registros de mis tablas para que los reciba el html

#def RespCorrecta(request):

    #be = (request.POST['Pregunta'])
 #   n1 =(request.POST['option_elegida'])
  #  if n1 == 0 :
   #       puntajeObj2 = 0
    #elif n1 == 1:
     #     puntajeObj2= 10

    #obt = Juego.objects.create(puntajeObj = 10, activo=1)
    #obt.save()
       
    #ale =randint(1,24) #genero numero aleatorio para el id de la pregunta que deseo mostrar
    #p = Pregunta.objects.get(id=ale) #guardo en variable p todos los registros de mi tabla que contengan el id generado
    #gr =Respuesta.objects.filter(pregunta=2) #busco todos los registros en respuestas que esten asociados al id de la pregunta generada
    #return render(request,'FormularioGame.html',{'p2':p,'gr1':gr}) #envio como tercer parámetro las variables donde guarde los registros de mis tablas para que los reciba el html


    
      
      

# ---------------------------------------------------------------
#def ReJuego(request):
    #nombre = request.POST.get("firstname")
    #apellido = request.POST.get("firstname")
    #Jugador.objects.Create(nombreJugador=nombre,)
    #Jugador.save()
    #  hh=10
    # jj= 1
    #x= Juego(puntajeObj = hh,activo = jj)
    #x.save()
    #return render(request,'Juego.html')
# ---------------------------------------------------------------
def RegistroLogin(request):
    if request.method =='POST':
        form = RegistroForm(request.POST)
        if form.is_valid():
             form.save()
        return redirect('templates:RegistroForm')     
    else:
          form = RegistroForm()
    return render(request,'templates/RegistroForm.html',{'form':form})
         
  # ---------------------------------------------------------------   
    
    #nombre = request.POST.get("nombre")
    #genero = request.POST.get("genero")
    #email = request.POST.get("correo")
    #phono = request.POST.get("edad")
    #user = request.POST.get("usuario")
    #password = request.POST.get("contraseña")
    
    #Jugador.objects.Create(nombreJugador=nombre,)
    #Jugador.save()

   # x= Juego(puntajeObtenido = 10,activo = 1)
    #x.save()
    #return render(request,'Juego.html')

# ---------------------------------------------------------------


