from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from allauth.account.signals import user_signed_up

# Create your models here.
from django.urls import reverse #Used to generate URLs by reversing the URL patterns

@receiver(user_signed_up)
def create_user_profile(request, user, **kwargs):
    profile = Profile.objects.create(user=user)
    profile.save()

# --------------------------------------------------------------- #
class Jugador(models.Model):
    nombreJugador = models.CharField(max_length=20)
    generoJugador = models.CharField(max_length=1)
    edadJugador = models.IntegerField()
    correoJugador = models.EmailField()
    puntajeTotal = models.IntegerField()
    usuarioJugador=models.CharField(max_length=30)
    contraseñaJugador = models.CharField(max_length=30)


class Usuario(models.Model):
    nombre = models.CharField(max_length=20)
    genero = models.CharField(max_length=1)
    edad = models.IntegerField()
    correo = models.EmailField()
    usuario =models.CharField(max_length=30)
    contraseña = models.CharField(max_length=30)
    

class Juego(models.Model):
    
    puntajeObj = models.IntegerField()
    activo =  models.IntegerField()
    #jugador = models.ForeignKey(Jugador,null=True,blank=True,on_delete=models.DO_NOTHING)



class Administrador(models.Model):
    nombreAdmin=models.CharField(max_length=50)
    correoRoot=models.EmailField()
    UsuarioRoot=models.CharField(max_length=30)
    contraseñaRoot=models.CharField(max_length=20)
    juego = models.ForeignKey(Jugador,null=True,on_delete=models.DO_NOTHING)


class Pregunta(models.Model):
  
    preguntas = models.CharField(max_length=70)
    
class Respuesta(models.Model):
    
    respuesta = models.CharField(max_length=70)
    correcta=models.IntegerField()
    pregunta = models.ForeignKey(Pregunta,null=True,on_delete=models.DO_NOTHING)

# -- Usuario para el login -- #

class Perfil(models.Model):
    usuario = models.OneToOneField(User, on_delete=models.CASCADE)
    bio = models.CharField(max_length=255, blank=True)
    web = models.URLField(blank=True)

    # Python 3
    def __str__(self): 
        return self.usuario.username

@receiver(post_save, sender=User)
def crear_usuario_perfil(sender, instance, created, **kwargs):
    if created:
        Perfil.objects.create(usuario=instance)

@receiver(post_save, sender=User)
def guardar_usuario_perfil(sender, instance, **kwargs):
    instance.perfil.save()

        