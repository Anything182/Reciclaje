from django.conf.urls import url
from django.urls import path
from . import views
from django.views.generic.base import TemplateView # new
from .views import Aceite,RegistrarseForm,Inicio,login,Bronce,Carton,Electrodomesticos,Registro,Metales,Neumaticos,Plasticos,Juego,Tapas,Telgopor,TetraPack,Textiles,Vidrios,PagJuego
from .views import Prueba, listarRegistro,modificarJugador,eliminarJugador,Mapa,CRUD


urlpatterns = [
    url(r'^$', views.index, name='index'),
    path('Aceite.html/',Aceite, name="Aceite"),
    path('Bronce.html/',Bronce, name="Bronce"),
    path('Carton.html/',Carton, name="Carton"),
    path('Electrodomesticos.html/',Electrodomesticos, name="Electrodomesticos"),
    path('Metales.html/',Metales, name="Metales"),
    path('Neumaticos.html/',Neumaticos, name="Neumaticos"),
    path('Plasticos.html/',Plasticos, name="Plasticos"),
    path('Tapas.html/',Tapas, name="Tapas"),
    path('Telgopor.html/',Telgopor, name="Telgopor"),
    path('TetraPack.html/',TetraPack, name="TetraPack"),
    path('Textiles.html/',Textiles, name="Textiles"),
    path('Vidrios.html/',Vidrios, name="Vidrios"),
    path('Juego.html/',Juego, name="Juego"),
    path('Inicio.html/',Inicio, name="Inicio"),
    path('login.html/',login, name="login"),
    path('Registro.html/',Registro, name="Registro"),
    path('pag.html/',PagJuego, name="pagJuego"),
    path('Mapa.html/',Mapa, name="Map"),
    path('eliminarJugador.html/',CRUD, name="CRUD"),
    path('RegistraseForm.html/',Prueba, name="Registro1"),
    url(r'^listarRegistro/', listarRegistro, name='listadoJugador'),
    url(r'^modificarJugador/(?P<id>/d+)$', modificarJugador, name='jugadorModificado'),
    url(r'^eliminarJugador/(?P<id>/d+)$', eliminarJugador, name='jugadorEliminado'),
   
    


              ]



