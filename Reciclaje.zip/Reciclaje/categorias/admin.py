from django.contrib import admin

# Register your models here.

from .models import  Administrador,Juego,Jugador,Pregunta,Respuesta,Usuario,User
from .form import RegModelForm

class AdminRegistrado(admin.ModelAdmin):
    list_display = ["nombreJugador","generoJugador","correoJugador","usuarioJugador","contraseñaJugador"]
    form = RegModelForm
    list_filter = ["timestamp"]
    list_editable= ["nombre"]
    search_fields= ["email","nombre"]
     
   

admin.site.register(Administrador)
admin.site.register(Juego)
admin.site.register(Jugador)
admin.site.register(Pregunta)
admin.site.register(Respuesta)
admin.site.register(Usuario)


